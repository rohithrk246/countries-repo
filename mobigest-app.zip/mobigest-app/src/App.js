
import React from 'react'
import './App.css'
import RouteComp from './Components/RouteComp'


const App = ()=>{
  
return(
  <div>
    <RouteComp/>
  </div>
  )
}

export default App;
