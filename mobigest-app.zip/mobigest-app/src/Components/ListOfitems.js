import React, { useState } from "react";
import {Link} from 'react-router-dom';
const ListOfItems = ({ items }) => {
  const [search, setSearch] = useState([]);
  const [inputval, setInputval] = useState("");
  let finalResult = [];

  const serachitem = (event) => {
    const value = event.target.value;
    setInputval(value);
    // debugger;
    finalResult = items.filter((item) => {
      if (item.name.toLowerCase().includes(value)) {
          console.log(item.name)
        return item.name;
      } 
    });

    setSearch(finalResult);
  };
  const postdata = (e) => {
    e.preventDefault();
    let obj = {
      name: inputval,
    };
    let arrayCopy = items;
    arrayCopy.push(obj);
    setSearch(arrayCopy);

  };
  return (
    <div>
      <form className="myform">
        <select className="selectlist">
          <option>List of countries ....</option>
          {items.map((item) => (
            <option>{item.name}</option>
          ))}
        </select>


        <input
          type="text"
          placeholder="Search Country Name"
          value={inputval}
          onChange={(e) => serachitem(e)}
        ></input>

        <div className="searchList">
          {search.length == 0 ? (
            <div className="initial">
              
              No matches found for " {inputval} "
              <button className="btn" onClick={postdata}>
           <Link to="/add"> Add/Post  </Link>
              </button>
            </div>
          ) : (
            search.map((item) => <div className="Optionlist">{item.name}</div>)
          )}
        </div>
      </form>
    </div>
  );
};
export default ListOfItems;
